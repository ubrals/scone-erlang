When updating the unicode version copy the necessary files to this
directory.
And update the test files in stdlib/test/unicode_util_SUITE_data/*

Unicode 12.1 was updated from:
https://www.unicode.org/Public/12.1.0/ucd/
https://www.unicode.org/Public/12.1.0/ucd/auxiliary/
https://www.unicode.org/Public/emoji/12.0/

Update the spec_version(..) function in the generator,
gen_unicode_mod.escript
