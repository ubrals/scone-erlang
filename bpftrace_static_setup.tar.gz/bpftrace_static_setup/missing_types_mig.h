/* SPDX-License-Identifier: GPL-2.0 WITH Linux-syscall-note */
/* mig extended */
#ifndef _LINUX_ELF_H
#define _LINUX_ELF_H

#include <linux/types.h>
#include <linux/elf-em.h>

/* 64-bit ELF base types. */
typedef __s64	s64;

/* others */
typedef unsigned short      umode_t;

#endif
