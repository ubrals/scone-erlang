sudo mount -o loop,nosuid /opt/bpftrace/file_block.ext3 /mnt/bpft

